from random import randint
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from robot.libraries.BuiltIn import BuiltIn

def getrandomnumber(n):
    range_start = 10**(int(n)-1)
    range_end = (10**int(n))-1
    return randint(range_start, range_end)

def converttodatetimeSD(str):
    date_object=datetime.strptime(str,"%m/%d/%Y")
    return date_object

def converttodatetimeInquiry(str):
    date_object=datetime.strptime(str,"%d-%b-%Y")
    return date_object

def converttodatetimeSEMS(str):
    date_object=datetime.strptime(str,"%b-%d-%Y")
    return date_object

def enterbarcode(driver,barcode):
    actions = ActionChains(driver)
    actions.send_keys(barcode)
    actions.send_keys(Keys.ENTER)
    actions.perform()

def get_webdriver_instance():
    se2lib = BuiltIn().get_library_instance('Selenium2Library')
    return se2lib._current_browser()