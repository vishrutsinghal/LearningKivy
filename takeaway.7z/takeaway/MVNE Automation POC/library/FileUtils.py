class FileUtils(object):

    def csv_as_dict(self, csvfile):

        import csv

        with open(csvfile) as f:
            reader = csv.DictReader(f)
            dict_list = []
            for line in reader:
                    dict_list.append(line)
        return dict_list