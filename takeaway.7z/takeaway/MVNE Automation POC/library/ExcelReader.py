class ExcelReader(object):

    def read_data(self,filelocation,sheetname):

        from xlrd import open_workbook

        dict_list = []
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)

        # read first row for keys
        keys = sheet.row_values(0)

        # read the rest rows for values
        values = [sheet.row_values(i) for i in range(1, sheet.nrows)]

        for value in values:
            dict_list.append(dict(zip(keys, value)))

        return dict_list

    def merge_dictionary(self,testdata,environmentparameters):
        testdata.update(environmentparameters)
        return testdata
