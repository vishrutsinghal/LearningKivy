
def removewhitespace(n):
    n = n.strip()
    n = n.replace(" " ,"")
    return n
