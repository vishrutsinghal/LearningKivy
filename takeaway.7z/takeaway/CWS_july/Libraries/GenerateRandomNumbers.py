from random import randint


def getrandomnumber(n):
    range_start = 10 ** (int(n) - 1)
    range_end = (10 ** int(n)) - 1
    return randint(range_start, range_end)
