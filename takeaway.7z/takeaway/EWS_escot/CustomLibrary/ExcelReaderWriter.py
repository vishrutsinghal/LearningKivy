import xlrd
import xlwt
from xlutils.copy import copy
from xlwt import XFStyle, Borders, Pattern, Font

global filelocation
global sheet

# count the number of rows in a sheet

def getRowCount(filelocation, sheetName):
    wbR = xlrd.open_workbook(filelocation, formatting_info=True)
    sh = wbR.sheet_by_name(sheetName)
    row_count = sh.nrows
    return row_count

# retrieve the content of a row
def getRowData(row, filelocation, sheetName):
    variables = []
    row = int(row)
    wbR = xlrd.open_workbook(filelocation, formatting_info=True)
    sh = wbR.sheet_by_name(sheetName)
    cell = sh.cell(0,0)
    for i in range(sh.ncols):
        variables.append(sh.cell_value(row,i))
    return variables


    
# Append content to a specific column, content will be in bold black colour, if content = Pass, text color will be green, if content = Fail, text colour will be red 
def appendResult(outputFile, sheetName, row, col, content):
    row = int(row)
    col = int(col)   
    rb = xlrd.open_workbook(outputFile, formatting_info=True)
    sh = rb.sheet_by_name(sheetName)
    sheetList = rb.sheet_names()
    wb = copy(rb)
    sheetIndex = sheetList.index(sheetName)  
    sheet = wb.get_sheet(sheetIndex)
    min_col_width = 13*265
    sheet.col(col).width = min_col_width
    if(len(content)*265) > min_col_width:
        sheet.col(col).width = (len(content)*160)
    else:
        sheet.col(col).width = min_col_width
    # if row is header, apply header style
    if row == 0:
        sheet.write(row,col,content,applyHeaderStyle())
    #else apply col style
    else:
        if content == 'Pass':
            sheet.write(row,col,content,applyColStyle('Pass'))
        elif content == 'Fail':
            sheet.write(row,col,content,applyColStyle('Fail'))
        else:
            sheet.write(row,col,content,applyColStyle(content))
    wb.save(outputFile)



################ Style Methods ####################

# style the header of a sheet
def applyHeaderStyle():
    fnt = Font()
    fnt.name = 'Calibri'
    fnt.height = 220
    fnt.bold = True
    borders = Borders()
    borders.left = Borders.THIN
    borders.right = Borders.THIN
    borders.top = Borders.THIN
    borders.bottom = Borders.THIN
    pattern = Pattern()
    pattern.pattern = Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 0x16
    style = XFStyle()
    style.font = fnt
    style.borders = borders
    style.pattern = pattern
    return style
    
# style for a specific column, text will be green if it's Pass, red if it's Fail, otherwise black
def applyColStyle(colContent):
    fnt = Font()
    fnt.name = 'Calibri'
    fnt.height = 220
    borders = Borders()
    borders.left = Borders.THIN
    borders.right = Borders.THIN
    borders.top = Borders.THIN
    borders.bottom = Borders.THIN
    if colContent == 'Pass':
        fnt.colour_index = 17 # colour_index for green is 3
        fnt.bold = True
    elif colContent == 'Fail':
        fnt.colour_index = 2 # colour_index for red is 2
        fnt.bold = True
    style = XFStyle()
    style.font = fnt
    style.borders = borders
##    style.pattern = pattern
    return style
############## End Style Methods ##################



# function to get the warranty service payment option ID for the given warranty and payment options.
def getsrvcID(warrantyoptn,paymentoptn):
    srvcID=0
    if  warrantyoptn == 'TELUS Device Care ' and paymentoptn.find("month") != -1:
         srvcID = 240 #MRC
    elif warrantyoptn == 'TELUS Device Care ' and paymentoptn.find("month") == -1:
         srvcID = 239 #PUF
    elif warrantyoptn == 'TELUS Device Care Premium ' and paymentoptn.find("month") == -1:
         srvcID = 241 #PUF
    elif warrantyoptn == 'TELUS Device Care Premium ' and paymentoptn.find("month") != -1:
         srvcID = 242 #MRC
    elif warrantyoptn == 'TELUS T-UP with Device Care ' and paymentoptn.find("month") != -1:
         srvcID = 243 #MRC
    elif warrantyoptn == 'TELUS T-Up with Apple Care +Apple Care +' and paymentoptn.find("month") != -1:
         srvcID = 246 #MRC
    elif warrantyoptn == 'Koodo Apple Care +' and paymentoptn.find("month") != -1:
         srvcID = 250 #MRC
    elif warrantyoptn == 'Koodo Apple Care +' and paymentoptn.find("month") == -1:
         srvcID = 249 #PUF
    elif warrantyoptn== 'Koodo Extended Warranty ' and paymentoptn.find("month") == -1:
         srvcID = 247 #PUF
    elif warrantyoptn == 'Koodo Extended Warranty ' and paymentoptn.find("month") != -1:
         srvcID = 248 #MRC
    elif warrantyoptn== 'Apple Care +' and paymentoptn.find("month") != -1:
         srvcID = 245 #MRC
    elif warrantyoptn == 'Apple Care +' and paymentoptn.find("month") == -1:
         srvcID = 244 #PUF
    return srvcID
