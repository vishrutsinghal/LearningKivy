class StringOperations(object):

    def replace_string_with_given_string(self,String, replaceable, newString):

         import string
         new_String= string.replace(String, replaceable, newString)
         return new_String

    def  to_add_the_new_data_as_per_match(self, ScriptData,tag_to_search, name):

         try:
             start = ScriptData.index(tag_to_search) + len(tag_to_search)
             end = ScriptData.index(name, start)
             return ScriptData[start:end]
         except ValueError:
             return ""