class FileUtils(object):

    def csv_as_dict(self, csvfile):

        import csv

        with open(csvfile) as f:
            reader = csv.DictReader(f)
            dict_list = []
            for line in reader:
                    dict_list.append(line)
        return dict_list

    def  file_current_directory(self):
        import os
        return  os.getcwd()

    def  file_current_directory_name(self,filename):
        import os
        full_path = os.path.dirname(filename)
        return  full_path