class ExcelReader(object):

    def read_data(self,filelocation,sheetname):

        from xlrd import open_workbook

        dict_list = []
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)

        # read first row for keys
        keys = sheet.row_values(0)

        # read the rest rows for values
        values = [sheet.row_values(i) for i in range(1, sheet.nrows)]

        for value in values:
            dict_list.append(dict(zip(keys, value)))

        return dict_list
    def read_data_keys_at_row_index (self,filelocation,rowIndex,sheetname):

        from xlrd import open_workbook

        dict_list = []
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)

        # read index row for keys
        keys = sheet.row_values(int(rowIndex))

        # read the rest rows for values
        values = [sheet.row_values(i) for i in range(int(rowIndex)+1, sheet.nrows)]

        for value in values:
            dict_list.append(dict(zip(keys, value)))

        return dict_list

    def merge_dictionary(self,testdata,environmentparameters):
        testdata.update(environmentparameters)
        return testdata

    def  write_data(self, filelocation, sheetname, rowNumber, value):
        import openpyxl
        wb = openpyxl.load_workbook(filelocation)
        ws = wb.get_sheet_by_name(sheetname)
        ws[rowNumber] = value
        wb.save(filelocation)