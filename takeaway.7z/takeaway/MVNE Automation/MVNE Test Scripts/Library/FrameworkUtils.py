import time
import win32com.client

class FrameworkUtils(object):
    def handle_login_popup(self, username, password):
         time.sleep(2)
         shell = win32com.client.Dispatch("WScript.Shell")
         shell.Sendkeys(username)
         time.sleep(2)
         shell.Sendkeys("{TAB}")
         shell.Sendkeys(password)
         time.sleep(2)
         shell.Sendkeys("{ENTER}")
         time.sleep(5)

    def click_on_Enter(self):
         time.sleep(2)
         shell = win32com.client.Dispatch("WScript.Shell")
         shell.Sendkeys("{ENTER}")
         time.sleep(5)