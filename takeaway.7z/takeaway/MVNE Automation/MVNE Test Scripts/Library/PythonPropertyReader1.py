import ConfigParser
config = ConfigParser.RawConfigParser()
config.read('../testdata//ConfigFile.properties')
print config.get('database.dbname');