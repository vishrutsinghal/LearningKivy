class FileUtils(object):

    def csv_as_dict(self, csvfile):

        import csv

        with open(csvfile) as f:
            reader = csv.DictReader(f)
            dict_list = []
            for line in reader:
                    dict_list.append(line)
        return dict_list

    def csv_to_replace_Data(self, csvfile, replaceData, newData):

      import csv
      res = []
      with open(csvfile) as f:
          content = csv.reader(f, delimiter=',')
          for row in content:
              for str in range(len(row)):
                  row[str] = row[str].replace(replaceData, newData)
              res.append(row)
          f.close()
      with open(csvfile, 'wb') as ff:  # python 3 => 'wb' => 'w',newline=''
          sw = csv.writer(ff, delimiter=',', quoting=csv.QUOTE_MINIMAL)
          for rows in res:
              sw.writerow(rows)
      ff.close()


    def  file_current_directory(self):
        import os
        return  os.getcwd()

    def  file_current_directory_name(self,filename):
        import os
        full_path = os.path.dirname(filename)
        return  full_path

    def  to_change_the_file_extension(self, filename, extension):
        import os
        thisFile = filename
        base = os.path.splitext(thisFile)[0]
        os.rename(thisFile, base + extension)

    def to_rename_the_file(self, srcfilename, dstfilename):
        import os
        os.rename(srcfilename, dstfilename)

    def  to_read_data_replace(self, filename,textvalue):
        f = open(filename, 'r')
        message = f.read()
        replaced_content = message.replace('<xsl:otherwise></xsl:otherwise></xsl:choose></xsl:template>',textvalue)
        print(message)
        f.close()
        return  replaced_content

    def  to_search_for_the_data(self, searchstring):
        import re
        nameSTring = re.findall('<xsl:choose>(.*?)<xsl:otherwise>', searchstring)
        return   nameSTring

    def insert_data(string, index, data):
        return string[:index] + ' ' + data + ' ' + string[index:]

    def  to_add_the_new_data_for_a_given_file(self, filename, datavalue):
         xsl = open(filename, 'r')
         data = xsl.read()
         # tag_to_insert = """<xsl:when test="$ppname='"""+str(idValue)+"""'">"""+str(datavalue)+"""</xsl:when>
         # """

         tag_to_insert =   str(datavalue)

         index_to_insert = data.rfind('</xsl:when>') + 12
         newdata = data[:index_to_insert] + ' ' + '\n' + tag_to_insert + ' ' + '\n' + data[index_to_insert:]

         f  =   open(filename, 'w')
         f.write(newdata)
         f.close()

    def  to_add_the_new_data_as_per_match_in_a_file(self, filename,tag_to_search, name):
         xsl = open(filename, 'r')
         data = xsl.read()

         try:
             start = data.index(tag_to_search) + len(tag_to_search)
             end = data.index(name, start)
             return data[start:end]
         except ValueError:
             return ""


    def to_replace_the_new_data(self, filename, oldData, newData):

        s = open(filename).read()
        s =  s.replace(oldData, newData)
        f = open(filename, 'w')
        f.write(s)
        f.close()

    def to_update_the_filename(self, path):
        import os
        results = []
        files = os.listdir(path)
        for file in files:
            filename, file_extension = os.path.splitext(file)
            results.append(filename + "Double" + file_extension)
            os.rename(os.path.join(path, file), os.path.join(path, filename + "Double" + file_extension))
        return   results

