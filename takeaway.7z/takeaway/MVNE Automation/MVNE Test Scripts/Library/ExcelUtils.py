class ExcelUtils(object):

    def read_data(self,filelocation,sheetname):

        from xlrd import open_workbook

        dict_list = []
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)

        # read first row for keys
        keys = sheet.row_values(0)

        # read the rest rows for values
        values = [sheet.row_values(i) for i in range(1, sheet.nrows)]

        for value in values:
            dict_list.append(dict(zip(keys, value)))

        return dict_list
    def read_data_keys_at_row_index (self,filelocation,rowIndex,sheetname):

        from xlrd import open_workbook

        dict_list = []
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)

        # read index row for keys
        keys = sheet.row_values(int(rowIndex))

        # read the rest rows for values
        values = [sheet.row_values(i) for i in range(int(rowIndex)+1, sheet.nrows)]

        for value in values:
            dict_list.append(dict(zip(keys, value)))

        return dict_list

    def merge_dictionary(self,testdata,environmentparameters):
        testdata.update(environmentparameters)
        return testdata

    def  write_data(self, filelocation, sheetname, rowNumber, value):
        import openpyxl
        try:
            wb = openpyxl.load_workbook(filelocation)
        except ValueError as verr:
            # pass  # do job to handle: s does not contain anything convertible to int
            wb.close();
            wb = openpyxl.load_workbook(filelocation)
        except Exception as ex:
            # pass  # do job to handle: Exception occurred while converting to int
            wb.close();
            wb = openpyxl.load_workbook(filelocation)
        wb = openpyxl.load_workbook(filelocation)
        ws = wb.get_sheet_by_name(sheetname)
        ws[rowNumber] = value
        wb.save(filelocation)
        wb.close();

    def  write_single_row_data(self, filelocation, sheetname, dictionaryData, coulmnNames):
        from xlrd import open_workbook
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)
        import openpyxl
        wb = openpyxl.load_workbook(filelocation)
        ws = wb.get_sheet_by_name(sheetname)
        for cIdx, coulmnName  in enumerate(coulmnNames):
            # read first row for keys
            keys = sheet.row_values(0)
            column_index = 0
            for index, elem in enumerate(keys):
                if elem == coulmnName:
                    value=dictionaryData[coulmnName]
                    print('value2', value)
                    column_index=index
                    break
                #  index with start with 0 so we need to add 1
            column_index=column_index+1
            # if you know the row_index and column_index then we need to use below cell method
            ws.cell(row=2, column=column_index).value = value
        wb.save(filelocation)

    def  write_multiple_rows_data(self, filelocation, sheetname, multData, coulmnNames,rowIndexs):
        from xlrd import open_workbook
        book = open_workbook(filelocation)
        sheet = book.sheet_by_name(sheetname)
        import openpyxl
        wb = openpyxl.load_workbook(filelocation)
        ws = wb.get_sheet_by_name(sheetname)
        for idx, val in enumerate(multData):
            cns=coulmnNames[idx]
            row_index = rowIndexs[idx]
            dval=multData[idx]
            column_index = 0
            for cIdx, coulmName  in enumerate(cns):
                coulmnName=cns[cIdx]
                value=dval[coulmnName]
                # read first row for keys
                keys = sheet.row_values(0)
                for index, elem in enumerate(keys):
                    if elem == coulmnName:
                        column_index=index
                        break
                    #  index with start with 0 so we need to add 1
                column_index=column_index+1
                # if you know the row_index and column_index then we need to use below cell method
                ws.cell(row=row_index, column=column_index).value = value
                column_index =0
        wb.save(filelocation)