class DateUtils(object):

    def days_between_two_date(self, startDate,endDate,date_format):
        from datetime import datetime
        # date_format = "%Y-%m-%d"
        # date_format= "%Y-%m-%d %H:%M:%S.%f"
        # date_format = "YYYY-MM-DD hh:mm:ss.mil"
        a = datetime.strptime(startDate, date_format)
        b = datetime.strptime(endDate, date_format)
        delta = b - a
        # print delta.days
        return delta.days

    def validate_NRC_Date(self, startDate,endDate,addDays,date_format):
        from datetime import datetime
        from datetime import timedelta
        endDate = datetime.strptime(endDate, date_format)
        # addDays=addDays-1
        timeNow = datetime.strptime(startDate, date_format)
        if (addDays != 0):
            anotherTime = timeNow + timedelta(days=addDays)
        else:
            anotherTime = timeNow
        print addDays
        print startDate
        print endDate
        print addDays
        print anotherTime
        print endDate.date() == anotherTime.date()
        return endDate.date() == anotherTime.date()