class PythonPropertyReader(object):
  def get_property_value(self,filelocation, section, property_name):
        import ConfigParser
        config = ConfigParser.RawConfigParser()
        config.read(filelocation)
        return config.get(section, property_name);
