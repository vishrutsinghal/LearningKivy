class Certificate(object):

    def bypass_ssl_certificate(self):
        import ssl
        if hasattr(ssl,'_create_unverified_context'): ssl._create_default_https_context = ssl._create_unverified_context
