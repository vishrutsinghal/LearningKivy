class StringOperations(object):

    def replace_string_with_given_string(self,String, replaceable, newString):

         import string
         new_String= string.replace(String, replaceable, newString)
         return new_String

    def isInterger(self,String):

        try:
            i = int(String)
            return True
        except ValueError as verr:
            # pass  # do job to handle: s does not contain anything convertible to int
            return False
        except Exception as ex:
            # pass  # do job to handle: Exception occurred while converting to int
            return False

    def to_find_the_match_as_per_data(self, stringData, Match):

        import re
        if re.search(Match, stringData):
            return "True"
        else:
            return "False"

    def to_add_the_new_data_as_per_match(self, ScriptData, tag_to_search, name):

        try:
            start = ScriptData.index(tag_to_search) + len(tag_to_search)
            end = ScriptData.index(name, start)
            return ScriptData[start:end]
        except ValueError:
            return ""

    def to_add_the_new_data(self, data, regExpression, tag_to_insert):

        index_to_insert = data.rfind(regExpression) + 12
        newdata = data[:index_to_insert] + ' ' + tag_to_insert + ' ' + data[index_to_insert:]

        return newdata